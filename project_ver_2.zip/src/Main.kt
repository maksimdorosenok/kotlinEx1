fun main() {
    while(true){
     print("выберинте задание(1-3): ")
     val choose = readln()

     when(choose){
         "1" -> ex1()
         "2" -> ex2()
         "3" -> ex3()
         else -> print("такого задания не существует")
     }
 }


}

fun ex1() {
    print("-----------------\n")
    print("Введите сумму перевода в рублях: ")
    val amount = readln().toDouble()

    // Рассчитываем комиссию 0.75%
    var commission = amount * 0.0075

    // Применяем минимальную комиссию 35 рублей, если рассчитанная меньше
    if (commission < 35) {
        commission = 35.0
    }

    println("Сумма перевода: $amount руб.")
    println("Комиссия за перевод: $commission руб.")
    println("Итого к списанию: ${amount + commission} руб.")
    print("-----------------\n")
}

fun ex2(){
    print("-----------------\n")
    print("введите количество лайков: ")
    var likes = readln().toInt()

    val result = getLikesText(likes)
    println("Понравилось $likes $result")
    print("-----------------\n")
}

fun getLikesText(likes: Int): String {
    return when {
        likes % 100 in 11..14 -> "людям"
        likes % 10 == 1 -> "человеку"
        likes % 10 in 2..4 -> "людям"
        else -> "людям"
    }
}


fun ex3(){
    print("-----------------\n")
    var bil = false
    print("введите сумму покупки в рублях: ")
    var purchase = readln().toDouble()


    print("являетесь ли пользователь постоянным клиентом? ")
    val isRegular = readln().toBoolean()

    if((purchase > 1000) and (purchase <= 10000)){
        purchase -= 100
        print("Вам была дана скидка в размере 100 рублей! ")
        bil = true
    }
    else if(purchase > 10000) {
        val discount = purchase * 0.05
        purchase -= discount
        print("Вам была дана скидка под 5 процентов! ")
        bil = true
    }

    if(isRegular){
        val discount = purchase * 0.01
        purchase -= discount
        if(bil) {
            print("Также вы - постоянный покупатель! вам дана скидка под 1 процент. ")
        }else{
            print("Вам дана скидка под 1 процент как постоянному покупателю! ")
        }
    }
    print("Итговая сумма: $purchase\n")
    print("-----------------\n")
}